export class CreateUserDto{
        user_name: string; 
        user_password: string; 
        user_birth: Date; 
        user_email: string; 
        profil_id: number; 
}